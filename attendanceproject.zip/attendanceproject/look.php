<style>
fieldset
	{
	 border-color: #9F9C99;
	}
.a1
	{
	 background-color: #577284;
	 color: white;
	 font-size: 20px;
	 padding: 0.5px 0px 0.5px 0px;
     text-align: center;
	}
body
	{
		background-image: url("https://www.softwareshell.com/wp-content/uploads/2015/06/lybrary.png"); 
		background-repeat: no-repeat;
	}
</style>